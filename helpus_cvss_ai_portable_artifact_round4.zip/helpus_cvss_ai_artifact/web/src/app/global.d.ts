﻿declare module "*.css";
